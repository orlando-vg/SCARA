from setuptools import find_packages, setup

package_name = 'scara_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='mateo-lince',
    maintainer_email='mateo-lince@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [
        'xyz_publisher = scara_control.xyz_publisher:main',
        'teclado = scara_control.teclado:main',
        'hombremuerto = scara_control.hombremuerto:main',
    ],
    },
)
