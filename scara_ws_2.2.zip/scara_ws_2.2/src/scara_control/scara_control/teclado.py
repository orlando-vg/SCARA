#!/usr/bin/env python3
"""
Control del efector final del SCARA con el teclado.

Publica puntos (x, y, z) en metros en /scara/target_position, que es lo
que escucha la ESP32. Lee /scara/feedback (medida de los encoders) para
mostrar la posicion real y para no adelantar el objetivo demasiado
respecto al robot. Lee /scara/state si existe.

Teclas:
    W / S   +x / -x   (adelante / atras)
    A / D   +y / -y   (izquierda / derecha)
    R / F   +z / -z   (subir / bajar)
    + / -   aumentar / reducir el paso
    ESPACIO detener: el objetivo pasa a la posicion medida
    H       ir al home
    Q       salir
"""

import math
import os
import select
import sys
import termios
import time
import tty

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from std_msgs.msg import Float32MultiArray, String


# ============ PARAMETROS (deben coincidir con IK.c y main.c) ============

X_OFFSET = 0.0855
L1 = 0.101
L2 = 0.08291
Z_OFFSET = 0.1135

D1_MIN = -0.120
D1_MAX = 0.0
THETA_MAX = math.pi / 2.0

# Home: d1 = theta2 = theta3 = 0
HOME = (X_OFFSET + L1 + L2, 0.0, -Z_OFFSET)

PASOS = [0.001, 0.002, 0.005, 0.010, 0.020]   # metros
INDICE_PASO_INICIAL = 2                        # 5 mm

LEAD_MAX = 0.03            # m: maximo que el objetivo puede adelantarse a la medida
PERIODO_MIN_ENVIO = 0.05   # s: limite de envios por teclas repetidas
TIMEOUT_FEEDBACK = 0.5     # s: despues de esto la medida se considera vieja

MOVIMIENTOS = {
    'w': (1.0, 0.0, 0.0),
    's': (-1.0, 0.0, 0.0),
    'a': (0.0, 1.0, 0.0),
    'd': (0.0, -1.0, 0.0),
    'r': (0.0, 0.0, 1.0),
    'f': (0.0, 0.0, -1.0),
}

AYUDA = (
    "\nControl por teclado del SCARA\n"
    "  W/S: +x/-x    A/D: +y/-y    R/F: +z/-z\n"
    "  +/-: cambiar paso    ESPACIO: detener    H: home    Q: salir\n"
    "Nota: en home el brazo esta extendido al maximo; desde ahi solo se\n"
    "puede empezar con S (retraer) o con R/F (altura).\n\n"
)


# ============ CINEMATICA (copia de IK.c) ============

def cinematica_inversa(x, y, z):
    """Devuelve la lista de soluciones (d1, theta2, theta3), como IK.c."""
    xr = x - X_OFFSET
    d1 = z + Z_OFFSET

    c3 = (xr * xr + y * y - L1 * L1 - L2 * L2) / (2.0 * L1 * L2)
    if c3 < -1.0 or c3 > 1.0:
        return []

    s3 = math.sqrt(1.0 - c3 * c3)
    soluciones = []
    for s in (s3, -s3):
        t3 = math.atan2(s, c3)
        t2 = math.atan2(y, xr) - math.atan2(
            L2 * math.sin(t3), L1 + L2 * math.cos(t3)
        )
        # IK.c guarda theta3 con el signo invertido
        soluciones.append((d1, t2, -t3))
    return soluciones


def solucion_valida(sol):
    """Mismos limites que valida main.c."""
    d1, t2, t3 = sol
    return (
        D1_MIN <= d1 <= D1_MAX
        and -THETA_MAX <= t2 <= THETA_MAX
        and -THETA_MAX <= t3 <= THETA_MAX
    )


def es_alcanzable(x, y, z):
    return any(solucion_valida(s) for s in cinematica_inversa(x, y, z))


def cinematica_directa(d1, t2, t3):
    """Posicion cartesiana a partir de (d1, theta2, theta3) del firmware."""
    x = X_OFFSET + L1 * math.cos(t2) + L2 * math.cos(t2 - t3)
    y = L1 * math.sin(t2) + L2 * math.sin(t2 - t3)
    z = d1 - Z_OFFSET
    return (x, y, z)


def distancia(a, b):
    return math.sqrt(sum((p - q) ** 2 for p, q in zip(a, b)))


# ============ LOGICA DEL OBJETIVO (sin ROS) ============

class Objetivo:
    def __init__(self, inicio=HOME):
        self.punto = list(inicio)
        self.indice_paso = INDICE_PASO_INICIAL

    @property
    def paso(self):
        return PASOS[self.indice_paso]

    def cambiar_paso(self, delta):
        self.indice_paso = max(0, min(len(PASOS) - 1, self.indice_paso + delta))

    def intentar_mover(self, direccion, medida=None):
        """Mueve el objetivo un paso. Devuelve (ok, aviso)."""
        nuevo = [p + d * self.paso for p, d in zip(self.punto, direccion)]

        if not es_alcanzable(*nuevo):
            return False, 'fuera de alcance'

        if medida is not None:
            d_nuevo = distancia(nuevo, medida)
            d_actual = distancia(self.punto, medida)
            if d_nuevo > LEAD_MAX and d_nuevo > d_actual:
                return False, 'esperando al robot'

        self.punto = nuevo
        return True, ''


# ============ NODO ============

class TecladoScara(Node):

    def __init__(self):
        super().__init__('scara_teclado')

        self.publisher_ = self.create_publisher(
            Point, '/scara/target_position', 10
        )
        self.create_subscription(
            Float32MultiArray, '/scara/feedback', self.cb_feedback, 10
        )
        self.create_subscription(
            String, '/scara/state', self.cb_state, 10
        )

        self.objetivo = Objetivo()
        self.medida = None
        self.t_medida = 0.0
        self.estado = '?'

        self.aviso = ''
        self.t_aviso = 0.0

    # ---------- callbacks ----------

    def cb_feedback(self, msg):
        # indices 6..8 = medida (d1, theta2, theta3)
        if len(msg.data) < 9:
            return
        d1, t2, t3 = msg.data[6], msg.data[7], msg.data[8]
        self.medida = cinematica_directa(d1, t2, t3)
        self.t_medida = time.monotonic()

    def cb_state(self, msg):
        self.estado = msg.data

    # ---------- utilidades ----------

    def medida_vigente(self):
        if self.medida is None:
            return None
        if time.monotonic() - self.t_medida > TIMEOUT_FEEDBACK:
            return None
        return self.medida

    def avisar(self, texto):
        self.aviso = texto
        self.t_aviso = time.monotonic()

    def publicar(self):
        msg = Point()
        msg.x, msg.y, msg.z = (float(v) for v in self.objetivo.punto)
        self.publisher_.publish(msg)

    # ---------- acciones ----------

    def sincronizar_inicio(self, espera=1.5):
        """Toma la medida como objetivo inicial, sin publicar nada."""
        t0 = time.monotonic()
        while self.medida is None and time.monotonic() - t0 < espera:
            rclpy.spin_once(self, timeout_sec=0.05)

        medida = self.medida_vigente()
        if medida is None:
            print('Sin /scara/feedback: parto del home y no limito el adelanto.')
            return

        if es_alcanzable(*medida):
            self.objetivo.punto = list(medida)
            print('Objetivo inicial tomado de la posicion medida.')
        else:
            print('La medida actual no es un punto valido: parto del home.')

    def mover(self, direccion):
        ok, aviso = self.objetivo.intentar_mover(
            direccion, self.medida_vigente()
        )
        if ok:
            self.publicar()
        else:
            self.avisar(aviso)

    def detener(self):
        medida = self.medida_vigente()
        if medida is None:
            self.avisar('sin medida para detener')
            return
        if not es_alcanzable(*medida):
            self.avisar('la medida no es un punto valido')
            return
        self.objetivo.punto = list(medida)
        self.publicar()
        self.avisar('detenido')

    def ir_a_home(self):
        self.objetivo.punto = list(HOME)
        self.publicar()
        self.avisar('yendo a home')

    def linea_estado(self):
        o = self.objetivo.punto
        txt = f'objetivo x={o[0]:.4f} y={o[1]:+.4f} z={o[2]:.4f}'
        m = self.medida_vigente()
        if m is not None:
            txt += f' | medida x={m[0]:.4f} y={m[1]:+.4f} z={m[2]:.4f}'
        else:
            txt += ' | medida --'
        txt += f' | paso {self.objetivo.paso * 1000:.0f} mm | {self.estado}'
        if self.aviso and time.monotonic() - self.t_aviso < 1.5:
            txt += f' | {self.aviso}'
        return txt


def main(args=None):
    if not sys.stdin.isatty():
        print('Este nodo necesita una terminal interactiva.')
        return

    rclpy.init(args=args)
    node = TecladoScara()

    fd = sys.stdin.fileno()
    ajustes = termios.tcgetattr(fd)

    try:
        tty.setcbreak(fd)   # lee tecla a tecla, sin eco; Ctrl-C sigue activo

        node.sincronizar_inicio()
        print(AYUDA, end='')

        t_envio = 0.0
        t_pantalla = 0.0
        salir = False

        while rclpy.ok() and not salir:
            rclpy.spin_once(node, timeout_sec=0.0)

            listo, _, _ = select.select([fd], [], [], 0.03)
            if listo:
                datos = os.read(fd, 64)
                if not datos:
                    break

                # Teclas especiales (flechas, etc.) empiezan con ESC: se ignoran
                if datos[:1] != b'\x1b':
                    tecla = chr(datos[-1]).lower()
                    ahora = time.monotonic()

                    if tecla == 'q':
                        salir = True
                    elif tecla in MOVIMIENTOS:
                        if ahora - t_envio >= PERIODO_MIN_ENVIO:
                            node.mover(MOVIMIENTOS[tecla])
                            t_envio = ahora
                    elif tecla in ('+', '='):
                        node.objetivo.cambiar_paso(+1)
                    elif tecla == '-':
                        node.objetivo.cambiar_paso(-1)

                    elif tecla == 'h':
                        node.ir_a_home()

            ahora = time.monotonic()
            if ahora - t_pantalla >= 0.1:
                sys.stdout.write('\r\x1b[K' + node.linea_estado())
                sys.stdout.flush()
                t_pantalla = ahora

    except KeyboardInterrupt:
        pass
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, ajustes)
        print('\nCerrando nodo...')
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
