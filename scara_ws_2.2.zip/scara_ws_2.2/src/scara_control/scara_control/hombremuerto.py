#!/usr/bin/env python3

import threading

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool

from evdev import InputDevice, list_devices, ecodes


class HombreMuerto(Node):

    def __init__(self):
        super().__init__('hombre_muerto')

        self.publisher_ = self.create_publisher(
            Bool,
            '/scara/deadman',
            10
        )

        # Por seguridad empieza desactivado
        self.space_presionado = False

        # Buscar teclado
        self.teclado = self.buscar_teclado()

        # Hilo que escucha SPACE
        self.hilo_teclado = threading.Thread(
            target=self.leer_teclado,
            daemon=True
        )
        self.hilo_teclado.start()

        # Publicar continuamente el estado
        self.timer = self.create_timer(
            0.05,
            self.publicar_estado
        )


    def buscar_teclado(self):

        for ruta in list_devices():

            try:
                dispositivo = InputDevice(ruta)
            except PermissionError:
                continue

            capacidades = dispositivo.capabilities()

            if ecodes.EV_KEY not in capacidades:
                dispositivo.close()
                continue

            teclas = capacidades[ecodes.EV_KEY]

            # Solo necesitamos un dispositivo que tenga SPACE
            if ecodes.KEY_SPACE in teclas:
                return dispositivo

            dispositivo.close()

        raise RuntimeError(
            'No se encontro un teclado accesible'
        )


    def leer_teclado(self):

        try:
            for evento in self.teclado.read_loop():

                if evento.type != ecodes.EV_KEY:
                    continue

                if evento.code != ecodes.KEY_SPACE:
                    continue

                # 1 = presionada
                if evento.value == 1:
                    self.space_presionado = True

                # 0 = soltada
                elif evento.value == 0:
                    self.space_presionado = False

                # 2 = repeticion automatica
                # No hacemos nada

        except Exception:
            # Si se pierde el teclado, por seguridad
            # el hombre muerto queda desactivado
            self.space_presionado = False


    def publicar_estado(self):

        msg = Bool()
        msg.data = self.space_presionado

        self.publisher_.publish(msg)


def main(args=None):

    rclpy.init(args=args)

    node = HombreMuerto()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        # Al cerrar, dejar siempre el deadman desactivado
        msg = Bool()
        msg.data = False
        node.publisher_.publish(msg)

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()