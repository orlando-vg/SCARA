import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point

class XYZPublisher(Node): #Nodo XYZPublisher

    def __init__(self):
        super().__init__('xyz_publisher')
        #Defino el tipo de mensaje que va a ser tipo Point
        #y el número de mensajes en la cola
        self.publisher_ = self.create_publisher( 
            Point,
            '/scara/target_position',
            10
        )
    def publish_coordinates(self, x, y, z):
        msg = Point()

        msg.x = float(x)
        msg.y = float(y)
        msg.z = float(z)

        self.publisher_.publish(msg)

        self.get_logger().info(
            f'Objetivo enviado: x={msg.x}, y={msg.y}, z={msg.z}'
        )
def main(args=None):
    rclpy.init(args=args)

    node = XYZPublisher()

    while rclpy.ok():
        try:
            x = float(input('Ingrese x: '))
            y = float(input('Ingrese y: '))
            z = float(input('Ingrese z: '))

            node.publish_coordinates(x, y, z)

        except ValueError:
            print('Entrada no válida. Debes ingresar números.')

        except KeyboardInterrupt:
            print('\nCerrando nodo...')
            break

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()