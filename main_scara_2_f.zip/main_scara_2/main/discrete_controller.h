#ifndef DISCRETE_CONTROLLER_H
#define DISCRETE_CONTROLLER_H

#define CONTROLLER_TAU_I_MIN_S 0.0001f

typedef struct {
    float kp;
    float tau_d;
    float tau_i;
    float sample_time;
    float q0;
    float q1;
    float q2;
    float error_n_1;
    float error_n_2;
    float control_n_1;
    float output_min;
    float output_max;
    float last_unsaturated;
    float last_output;
    int saturated;
} discrete_controller_t;

void discrete_controller_init(
    discrete_controller_t *controller,
    float kp,
    float tau_d,
    float tau_i,
    float sample_time,
    float output_min,
    float output_max);
void discrete_controller_set_gains(
    discrete_controller_t *controller,
    float kp,
    float tau_d,
    float tau_i);
void discrete_controller_reset(discrete_controller_t *controller);
/* Sustituye u[n-1] por la salida realmente aplicada (anti-windup externo). */
void discrete_controller_force_output(
    discrete_controller_t *controller,
    float output);
float discrete_controller_update(
    discrete_controller_t *controller,
    float reference,
    float measurement);

#endif
