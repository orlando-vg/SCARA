#ifndef ROBOT_TYPES_H
#define ROBOT_TYPES_H

typedef enum {
    JOINT_P = 0,
    JOINT_R1,
    JOINT_R2,
    JOINT_COUNT
} joint_id_t;

typedef enum {
    SYSTEM_WAIT_HOME = 0,
    SYSTEM_HOMING,
    SYSTEM_READY,
    SYSTEM_CONTROL,
    SYSTEM_FAULT
} system_state_t;

#endif
