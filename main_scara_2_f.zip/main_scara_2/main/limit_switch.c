#include "limit_switch.h"

#include <stdint.h>
#include "board_config.h"
#include "driver/gpio.h"
#include "esp_err.h"

typedef struct {
    gpio_num_t gpio;
    bool stable_pressed;
    bool last_raw_pressed;
    uint32_t stable_ms;
} switch_t;

static switch_t s_switches[JOINT_COUNT] = {
    [JOINT_P]  = {.gpio = LIMIT_P_GPIO},
    [JOINT_R1] = {.gpio = LIMIT_R1_GPIO},
    [JOINT_R2] = {.gpio = LIMIT_R2_GPIO},
};

void limit_switches_init(void)
{
    const gpio_config_t config = {
        .pin_bit_mask = (1ULL << LIMIT_P_GPIO) |
                        (1ULL << LIMIT_R1_GPIO) |
                        (1ULL << LIMIT_R2_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&config));

    for (int i = 0; i < JOINT_COUNT; ++i) {
        bool raw = gpio_get_level(s_switches[i].gpio) == LIMIT_ACTIVE_LEVEL;
        s_switches[i].stable_pressed = raw;
        s_switches[i].last_raw_pressed = raw;
        s_switches[i].stable_ms = 0;
    }
}

void limit_switches_update(unsigned elapsed_ms)
{
    for (int i = 0; i < JOINT_COUNT; ++i) {
        switch_t *sw = &s_switches[i];
        bool raw = gpio_get_level(sw->gpio) == LIMIT_ACTIVE_LEVEL;
        if (raw != sw->last_raw_pressed) {
            sw->last_raw_pressed = raw;
            sw->stable_ms = 0;
        } else if (sw->stable_ms < LIMIT_DEBOUNCE_MS) {
            sw->stable_ms += elapsed_ms;
        }

        if (sw->stable_ms >= LIMIT_DEBOUNCE_MS) {
            sw->stable_pressed = raw;
        }
    }
}

bool limit_switch_is_pressed(joint_id_t joint)
{
    if (joint < 0 || joint >= JOINT_COUNT) {
        return false;
    }
    return s_switches[joint].stable_pressed;
}
