#ifndef JOINT_MODEL_H
#define JOINT_MODEL_H

#include <stdbool.h>
#include <stdint.h>
#include "robot_types.h"

float joint_position_from_pulses(joint_id_t joint, int32_t pulses);
float joint_home_position(joint_id_t joint);
float joint_min_position(joint_id_t joint);
float joint_max_position(joint_id_t joint);
int32_t joint_home_pulses(joint_id_t joint);
int32_t joint_min_pulses(joint_id_t joint);
int32_t joint_max_pulses(joint_id_t joint);
bool joint_target_is_valid(joint_id_t joint, float target_internal);
float degrees_to_radians(float degrees);
float radians_to_degrees(float radians);

#endif
