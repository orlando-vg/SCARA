#ifndef MOTOR_DRIVER_H
#define MOTOR_DRIVER_H

#include <stdbool.h>
#include <stdint.h>
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "robot_types.h"

typedef enum {
    MOTOR_STOPPED = 0,
    MOTOR_TOWARD_LIMIT,
    MOTOR_AWAY_FROM_LIMIT
} motor_direction_t;

typedef struct {
    joint_id_t joint;
    gpio_num_t stby_gpio;
    gpio_num_t dir1_gpio;
    gpio_num_t dir2_gpio;
    gpio_num_t pwm_gpio;
    ledc_channel_t ledc_channel;
    bool positive_voltage_toward_limit;
    bool invert_polarity;
    float requested_voltage;
    float duty_fraction;
    uint32_t duty_counts;
    int drive_sign;
    motor_direction_t direction;
} motor_driver_t;

/* Deja los TB6612FNG en standby y configura LEDC con duty 0. Llamar primero. */
void motor_driver_init_all(void);

/* Voltaje con signo (+/-). Positivo = DIR1 alto, DIR2 bajo (salvo polaridad invertida). */
void motor_driver_apply_voltage(joint_id_t joint, float requested_voltage);

/* Duty 0, DIR en bajo y STBY en bajo en ambos drivers. */
void motor_driver_stop_all(void);

/* true si ese voltaje empuja la articulacion hacia su final de carrera. */
bool motor_driver_voltage_is_toward_limit(joint_id_t joint, float voltage);

const motor_driver_t *motor_driver_get(joint_id_t joint);
const char *motor_direction_name(motor_direction_t direction);

#endif
