#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

#include <rcl/rcl.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>

#include "driver/uart.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <rmw_microxrcedds_c/config.h>
#include <rmw_microros/rmw_microros.h>

#include <geometry_msgs/msg/point.h>
#include <std_msgs/msg/bool.h>
#include <std_msgs/msg/float32_multi_array.h>
#include <std_msgs/msg/string.h>

#include "esp32_serial_transport.h"
#include "IK.h"
#include "scara_control.h"


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


/* ============ MICRO-ROS ============ */

rcl_subscription_t subscriber;
rcl_subscription_t deadman_subscriber;

rcl_publisher_t ik_publisher;

geometry_msgs__msg__Point msg;
geometry_msgs__msg__Point ik_msg;

std_msgs__msg__Bool deadman_msg;

bool deadman_activo = false;


/* ============ TELEMETRIA ============ */

/*
 * /scara/feedback (std_msgs/Float32MultiArray), 12 valores:
 *   [0..2]   objetivo final   : d1, theta2, theta3
 *   [3..5]   referencia rampa : d1, theta2, theta3
 *   [6..8]   medida (encoder) : d1, theta2, theta3
 *   [9..11]  error = objetivo - medida
 * d1 en metros, theta2 y theta3 en radianes.
 *
 * /scara/state (std_msgs/String): WAIT_HOME, HOMING, READY, CONTROL, FAULT
 */

#define FEEDBACK_PERIOD_MS  100   /* 10 Hz */
#define STATE_PERIOD_MS     500   /* 2 Hz y ademas al cambiar de estado */

rcl_publisher_t feedback_publisher;
rcl_publisher_t state_publisher;

static float feedback_data[12];
static char state_buffer[16];

std_msgs__msg__Float32MultiArray feedback_msg;
std_msgs__msg__String state_msg;

rclc_support_t support;
rcl_node_t node;
rclc_executor_t executor;


/* ============ CALLBACK ============ */
void deadman_callback(const void *msgin)
{
    const std_msgs__msg__Bool *received_msg =
        (const std_msgs__msg__Bool *)msgin;

    deadman_activo = received_msg->data;

    if (!deadman_activo) {
        scara_control_stop();
    }
}

void subscription_callback(const void *msgin)
{
    const geometry_msgs__msg__Point *received_msg =
        (const geometry_msgs__msg__Point *)msgin;

    /* ============ HOMBRE MUERTO ============ */

    if (!deadman_activo)
    {
        scara_control_stop();
        return;
    }


    printf(
        "Coordenadas recibidas: x=%.3f, y=%.3f, z=%.3f\n",
        received_msg->x,
        received_msg->y,
        received_msg->z
    );


    /* ============ CINEMATICA INVERSA ============ */

    IK_Solution solution_1;
    IK_Solution solution_2;
    IK_Solution selected_solution;


    bool reachable = inverse_kinematics(
        received_msg->x,
        received_msg->y,
        received_msg->z,
        &solution_1,
        &solution_2
    );


    if (!reachable)
    {
        printf("No se puede llegar a ese punto\n");
        return;
    }


    /* ============ VALIDAR SOLUCIONES ============ */

    bool solution_1_valid =
        solution_1.d1 >= -0.120 &&
        solution_1.d1 <= 0.0 &&
        solution_1.theta2 >= -M_PI / 2.0 &&
        solution_1.theta2 <=  M_PI / 2.0 &&
        solution_1.theta3 >= -M_PI / 2.0 &&
        solution_1.theta3 <=  M_PI / 2.0;


    bool solution_2_valid =
        solution_2.d1 >= -0.120 &&
        solution_2.d1 <= 0.0 &&
        solution_2.theta2 >= -M_PI / 2.0 &&
        solution_2.theta2 <=  M_PI / 2.0 &&
        solution_2.theta3 >= -M_PI / 2.0 &&
        solution_2.theta3 <=  M_PI / 2.0;


    /* ============ SELECCIONAR SOLUCION ============ */

    if (solution_1_valid)
    {
        selected_solution = solution_1;

        printf("Usando solucion 1\n");
    }
    else if (solution_2_valid)
    {
        selected_solution = solution_2;

        printf("Usando solucion 2\n");
    }
    else
    {
        printf("No se puede llegar a ese punto\n");
        return;
    }


    printf(
        "d1 = %.4f m, theta2 = %.4f rad, theta3 = %.4f rad\n",
        selected_solution.d1,
        selected_solution.theta2,
        selected_solution.theta3
    );


    /* ============ ENVIAR REFERENCIAS AL CONTROL ============ */

    bool target_accepted = scara_control_set_targets(
        (float)selected_solution.d1,
        (float)selected_solution.theta2,
        (float)selected_solution.theta3
    );


    if (!target_accepted)
    {
        printf(
            "El controlador no acepto la referencia. "
            "El robot puede no haber realizado homing.\n"
        );
    }


    /* ============ PUBLICAR SOLUCION IK ============ */

    ik_msg.x = selected_solution.d1;
    ik_msg.y = selected_solution.theta2;
    ik_msg.z = selected_solution.theta3;


    rcl_ret_t ret = rcl_publish(
        &ik_publisher,
        &ik_msg,
        NULL
    );


    if (ret != RCL_RET_OK)
    {
        printf("Error publicando solucion IK\n");
    }
}


/* ============ PUBLICAR TELEMETRIA ============ */

static void publish_telemetry(void)
{
    static TickType_t last_feedback = 0;
    static TickType_t last_state = 0;
    static int last_state_value = -1;

    TickType_t now = xTaskGetTickCount();

    scara_feedback_t fb;
    scara_control_get_feedback(&fb);


    if ((now - last_feedback) >= pdMS_TO_TICKS(FEEDBACK_PERIOD_MS))
    {
        last_feedback = now;

        for (int i = 0; i < JOINT_COUNT; i++)
        {
            feedback_data[i]     = fb.target[i];
            feedback_data[3 + i] = fb.reference[i];
            feedback_data[6 + i] = fb.measured[i];
            feedback_data[9 + i] = fb.target[i] - fb.measured[i];
        }

        rcl_ret_t fb_ret =
            rcl_publish(&feedback_publisher, &feedback_msg, NULL);
        (void)fb_ret;
    }


    if ((int)fb.state != last_state_value ||
        (now - last_state) >= pdMS_TO_TICKS(STATE_PERIOD_MS))
    {
        last_state = now;
        last_state_value = (int)fb.state;

        strncpy(
            state_buffer,
            scara_control_state_name(fb.state),
            sizeof(state_buffer) - 1
        );
        state_buffer[sizeof(state_buffer) - 1] = '\0';

        state_msg.data.size = strlen(state_buffer);

        rcl_ret_t st_ret =
            rcl_publish(&state_publisher, &state_msg, NULL);
        (void)st_ret;
    }
}


/* ============ UART MICRO-ROS ============ */

static size_t uart_port = UART_NUM_0;


/* ============ MAIN ============ */

void app_main(void)
{
    printf("Iniciando SCARA...\n");


    /* ============================================
     * INICIALIZAR CONTROL DEL ROBOT
     * ============================================ */

    scara_control_init();


    /*
     * Por ahora iniciamos el homing desde aqui.
     *
     * Cuando terminemos la integracion podemos
     * hacer que ROS mande un comando para iniciar
     * el homing en vez de hacerlo automaticamente.
     */

    scara_control_start_homing();


    /* ============================================
     * CONFIGURAR TRANSPORTE MICRO-ROS
     * ============================================ */

#if defined(RMW_UXRCE_TRANSPORT_CUSTOM)

    rmw_uros_set_custom_transport(
        true,
        (void *)&uart_port,
        esp32_serial_open,
        esp32_serial_close,
        esp32_serial_write,
        esp32_serial_read
    );

#else

#error micro-ROS transports misconfigured

#endif


    /* ============ SOPORTE MICRO-ROS ============ */

    rcl_allocator_t allocator =
        rcl_get_default_allocator();


    rclc_support_init(
        &support,
        0,
        NULL,
        &allocator
    );


    /* ============ NODO ============ */

    rclc_node_init_default(
        &node,
        "scara_esp32_node",
        "",
        &support
    );


    /* ============ SUBSCRIBER XYZ ============ */

    rclc_subscription_init_default(
        &subscriber,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(
            geometry_msgs,
            msg,
            Point
        ),
        "/scara/target_position"
    );

    rclc_subscription_init_default(
        &deadman_subscriber,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Bool),
        "/scara/deadman"
    );


    /* ============ PUBLISHER IK ============ */

    rclc_publisher_init_default(
        &ik_publisher,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(
            geometry_msgs,
            msg,
            Point
        ),
        "/scara/ik_solution"
    );


    /* ============ PUBLISHERS DE TELEMETRIA ============ */

    std_msgs__msg__Float32MultiArray__init(&feedback_msg);
    feedback_msg.data.data = feedback_data;
    feedback_msg.data.size = 12;
    feedback_msg.data.capacity = 12;

    std_msgs__msg__String__init(&state_msg);
    state_msg.data.data = state_buffer;
    state_msg.data.size = 0;
    state_msg.data.capacity = sizeof(state_buffer);

    rclc_publisher_init_default(
        &feedback_publisher,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(
            std_msgs,
            msg,
            Float32MultiArray
        ),
        "/scara/feedback"
    );

    rclc_publisher_init_default(
        &state_publisher,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(
            std_msgs,
            msg,
            String
        ),
        "/scara/state"
    );


    /* ============ EXECUTOR ============ */

    rclc_executor_init(
        &executor,
        &support.context,
        2,
        &allocator
    );


    rclc_executor_add_subscription(
        &executor,
        &subscriber,
        &msg,
        &subscription_callback,
        ON_NEW_DATA
    );

    rclc_executor_add_subscription(
        &executor,
        &deadman_subscriber,
        &deadman_msg,
        &deadman_callback,
        ON_NEW_DATA
    );


    printf("Nodo micro-ROS del SCARA iniciado.\n");


    /* ============ LOOP PRINCIPAL ============ */

    while (1)
    {
        rclc_executor_spin_some(
            &executor,
            RCL_MS_TO_NS(10)
        );

        publish_telemetry();
    }
}