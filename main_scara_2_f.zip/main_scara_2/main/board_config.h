#ifndef BOARD_CONFIG_H
#define BOARD_CONFIG_H

#include "driver/gpio.h"
#include "driver/ledc.h"

/* Encoders */
#define ENC_P_A_GPIO   GPIO_NUM_39
#define ENC_P_B_GPIO   GPIO_NUM_34
#define ENC_R1_A_GPIO  GPIO_NUM_35
#define ENC_R1_B_GPIO  GPIO_NUM_32
#define ENC_R2_A_GPIO  GPIO_NUM_33
#define ENC_R2_B_GPIO  GPIO_NUM_25

/* Finales de carrera, activos en nivel bajo */
#define LIMIT_P_GPIO   GPIO_NUM_12
#define LIMIT_R1_GPIO  GPIO_NUM_27
#define LIMIT_R2_GPIO  GPIO_NUM_14
#define LIMIT_ACTIVE_LEVEL 0

/* TB6612FNG de la prismatica */
#define STBY_P_GPIO    GPIO_NUM_2
#define DIR1_P_GPIO    GPIO_NUM_0
#define DIR2_P_GPIO    GPIO_NUM_4
#define PWM_P_GPIO     GPIO_NUM_16

/* TB6612FNG compartido por las dos revolutas */
#define STBY_R_GPIO    GPIO_NUM_19
#define DIR1_R1_GPIO   GPIO_NUM_18
#define DIR2_R1_GPIO   GPIO_NUM_5
#define PWM_R1_GPIO    GPIO_NUM_17

#define DIR1_R2_GPIO   GPIO_NUM_21
#define DIR2_R2_GPIO   GPIO_NUM_22
#define PWM_R2_GPIO    GPIO_NUM_23

/* Parametros temporales */
#define CONTROL_TS_S          0.010f
#define CONTROL_TASK_MS       10
#define STATUS_PERIOD_MS      2000
#define LIMIT_DEBOUNCE_MS     20

/* Actuador */
#define MOTOR_SUPPLY_V        12.0f
#define ACTUATOR_MIN_V       (-12.0f)
#define ACTUATOR_MAX_V         12.0f

/*
 * Interruptor maestro del actuador.
 * 1 = actuacion real (STBY, DIR y PWM se aplican a los TB6612FNG).
 * 0 = dry-run: todo se calcula y se imprime, pero STBY/PWM quedan en LOW.
 */
#define ACTUATION_ENABLED      1

/* PWM (LEDC, modo low-speed, un timer compartido por los tres motores) */
#define PWM_FREQ_HZ            20000
#define PWM_DUTY_BITS          10      /* 1023 pasos; PWM_FREQ_HZ * 2^bits <= 80 MHz */

/*
 * Polaridad de cada motor.
 *
 * Cableado del usuario: en las TRES articulaciones (DIR1=HIGH, DIR2=LOW) mueve
 * hacia el final de carrera. El modelo usa esta convencion de voltaje:
 *   P : voltaje positivo => hacia el final de carrera (encoder sube)
 *   R1: voltaje negativo => hacia el final de carrera (encoder baja)
 *   R2: voltaje negativo => hacia el final de carrera (encoder baja)
 * Con el driver "voltaje positivo => DIR1=1, DIR2=0", P queda directo y R1/R2
 * necesitan invertirse. Si alguna articulacion se mueve al reves al probar
 * (el homing avisa con "sentido invertido"), cambiar su valor aqui.
 */
#define MOTOR_P_INVERT_POLARITY   0
#define MOTOR_R1_INVERT_POLARITY  1
#define MOTOR_R2_INVERT_POLARITY  1

/* Homing automatico al energizar (1) o esperar el comando HOME por serial (0). */
#define AUTO_HOME_ON_BOOT         0
#define AUTO_HOME_DELAY_MS        3000   /* margen para cortar la alimentacion si algo va mal */

/* PCNT */
#define PCNT_LOW_LIMIT        (-30000)
#define PCNT_HIGH_LIMIT        30000
#define PCNT_GLITCH_FILTER_NS  1000

/* Homing en lazo abierto: voltajes que se aplican realmente al motor. */
#define HOMING_SEEK_V_P        2.0f
#define HOMING_SEEK_V_R1       2.0f
#define HOMING_SEEK_V_R2       2.0f
#define HOMING_BACKOFF_V       2.0f
#define HOMING_SECOND_V        2.0f
#define HOMING_TO_HOME_V       2.0f
#define HOMING_TIMEOUT_MS      30000

/* Homing: si el encoder se mueve mas de esto en contra del voltaje aplicado => fallo. */
#define HOMING_WRONG_DIR_PULSES     200
/* Homing: se considera que se llego a home al estar a esta distancia (o al pasarlo). */
#define HOMING_HOME_TOLERANCE_PULSES 2

/* Calibracion y limites medidos */
#define P_MIN_PULSES          (-48000)
#define P_MAX_PULSES           0
#define P_HOME_PULSES          0

#define R1_MIN_PULSES          0
#define R1_MAX_PULSES          7137
#define R1_HOME_PULSES         3756

#define R2_MIN_PULSES          0
#define R2_MAX_PULSES          7697
#define R2_HOME_PULSES         3815

/* Limites articulares */
#define P_MIN_M               (-0.115f)
#define P_MAX_M                0.0f
#define R1_MIN_RAD            (-1.6388642f)
#define R1_MAX_RAD             1.4752396f
#define R2_MIN_RAD            (-1.6497725f)
#define R2_MAX_RAD             1.7086773f

/* Pendientes maximas de referencia */
#define P_MAX_RATE_M_S         0.030f
#define R1_MAX_RATE_RAD_S      0.35f
#define R2_MAX_RATE_RAD_S      0.35f

/*
 * Ganancias iniciales en cero: en modo CONTROL no se aplica voltaje hasta
 * fijar ganancias con GAINS (o sustituir estos valores por los disenados).
 */
#define P_KP_INITIAL           5.76077f
#define P_TD_INITIAL           0.06746f / 5.76077f
#define P_TI_INITIAL           0.0f
#define R1_KP_INITIAL          5.76077f
#define R1_TD_INITIAL          0.06746f / 5.76077f
#define R1_TI_INITIAL          1.0f
#define R2_KP_INITIAL          5.76077f
#define R2_TD_INITIAL          0.06746f / 5.76077f
#define R2_TI_INITIAL          1.0f

/*
 * Proteccion de recorrido en modo CONTROL: si la posicion medida sale del
 * rango articular mas este margen, se corta el control (FAULT) y se exige HOME.
 */
#define SOFT_LIMIT_MARGIN_P_M     0.005f
#define SOFT_LIMIT_MARGIN_R_RAD   0.0873f   /* ~5 grados */

#endif
