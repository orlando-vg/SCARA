#ifndef LIMIT_SWITCH_H
#define LIMIT_SWITCH_H

#include <stdbool.h>
#include "robot_types.h"

void limit_switches_init(void);
void limit_switches_update(unsigned elapsed_ms);
bool limit_switch_is_pressed(joint_id_t joint);

#endif
