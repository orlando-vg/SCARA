#include "encoder.h"

#include <stddef.h>
#include "board_config.h"
#include "driver/gpio.h"
#include "driver/pulse_cnt.h"
#include "esp_err.h"

typedef struct {
    gpio_num_t gpio_a;
    gpio_num_t gpio_b;
    pcnt_unit_handle_t unit;
    pcnt_channel_handle_t channel_a;
    pcnt_channel_handle_t channel_b;
    int32_t zero_offset;
} encoder_t;

static encoder_t s_encoders[JOINT_COUNT] = {
    [JOINT_P]  = {.gpio_a = ENC_P_A_GPIO,  .gpio_b = ENC_P_B_GPIO},
    [JOINT_R1] = {.gpio_a = ENC_R1_A_GPIO, .gpio_b = ENC_R1_B_GPIO},
    [JOINT_R2] = {.gpio_a = ENC_R2_A_GPIO, .gpio_b = ENC_R2_B_GPIO},
};

static void encoder_configure(encoder_t *encoder)
{
    const pcnt_unit_config_t unit_config = {
        .low_limit = PCNT_LOW_LIMIT,
        .high_limit = PCNT_HIGH_LIMIT,
        .flags.accum_count = true,
    };
    ESP_ERROR_CHECK(pcnt_new_unit(&unit_config, &encoder->unit));

    const pcnt_chan_config_t channel_a_config = {
        .edge_gpio_num = encoder->gpio_a,
        .level_gpio_num = encoder->gpio_b,
    };
    const pcnt_chan_config_t channel_b_config = {
        .edge_gpio_num = encoder->gpio_b,
        .level_gpio_num = encoder->gpio_a,
    };

    ESP_ERROR_CHECK(pcnt_new_channel(
        encoder->unit, &channel_a_config, &encoder->channel_a));
    ESP_ERROR_CHECK(pcnt_new_channel(
        encoder->unit, &channel_b_config, &encoder->channel_b));

    ESP_ERROR_CHECK(pcnt_channel_set_edge_action(
        encoder->channel_a,
        PCNT_CHANNEL_EDGE_ACTION_DECREASE,
        PCNT_CHANNEL_EDGE_ACTION_INCREASE));
    ESP_ERROR_CHECK(pcnt_channel_set_level_action(
        encoder->channel_a,
        PCNT_CHANNEL_LEVEL_ACTION_KEEP,
        PCNT_CHANNEL_LEVEL_ACTION_INVERSE));

    ESP_ERROR_CHECK(pcnt_channel_set_edge_action(
        encoder->channel_b,
        PCNT_CHANNEL_EDGE_ACTION_INCREASE,
        PCNT_CHANNEL_EDGE_ACTION_DECREASE));
    ESP_ERROR_CHECK(pcnt_channel_set_level_action(
        encoder->channel_b,
        PCNT_CHANNEL_LEVEL_ACTION_KEEP,
        PCNT_CHANNEL_LEVEL_ACTION_INVERSE));

    const pcnt_glitch_filter_config_t filter_config = {
        .max_glitch_ns = PCNT_GLITCH_FILTER_NS,
    };
    ESP_ERROR_CHECK(pcnt_unit_set_glitch_filter(encoder->unit, &filter_config));

    ESP_ERROR_CHECK(pcnt_unit_add_watch_point(encoder->unit, PCNT_LOW_LIMIT));
    ESP_ERROR_CHECK(pcnt_unit_add_watch_point(encoder->unit, PCNT_HIGH_LIMIT));
    ESP_ERROR_CHECK(pcnt_unit_enable(encoder->unit));
    ESP_ERROR_CHECK(pcnt_unit_clear_count(encoder->unit));
    ESP_ERROR_CHECK(pcnt_unit_start(encoder->unit));
    encoder->zero_offset = 0;
}

/*
 * Correccion electrica comprobada en la PCB:
 * PCNT puede dejar pulls internos en GPIO25, GPIO32 y GPIO33.
 * Se deshabilitan DESPUES de crear los canales PCNT.
 */
static void force_output_capable_encoder_pins_floating(void)
{
    const gpio_num_t pins[] = {ENC_R1_B_GPIO, ENC_R2_A_GPIO, ENC_R2_B_GPIO};
    for (size_t i = 0; i < sizeof(pins) / sizeof(pins[0]); ++i) {
        gpio_pullup_dis(pins[i]);
        gpio_pulldown_dis(pins[i]);
        ESP_ERROR_CHECK(gpio_set_pull_mode(pins[i], GPIO_FLOATING));
    }
}

void encoders_init(void)
{
    for (int i = 0; i < JOINT_COUNT; ++i) {
        encoder_configure(&s_encoders[i]);
    }
    force_output_capable_encoder_pins_floating();
    encoders_set_zero_all();
}

int32_t encoder_get_raw_pulses(joint_id_t joint)
{
    int value = 0;
    if (joint < 0 || joint >= JOINT_COUNT) {
        return 0;
    }
    ESP_ERROR_CHECK(pcnt_unit_get_count(s_encoders[joint].unit, &value));
    return (int32_t)value;
}

int32_t encoder_get_pulses(joint_id_t joint)
{
    return encoder_get_raw_pulses(joint) - s_encoders[joint].zero_offset;
}

void encoder_set_zero(joint_id_t joint)
{
    if (joint >= 0 && joint < JOINT_COUNT) {
        s_encoders[joint].zero_offset = encoder_get_raw_pulses(joint);
    }
}

void encoders_set_zero_all(void)
{
    for (int i = 0; i < JOINT_COUNT; ++i) {
        encoder_set_zero((joint_id_t)i);
    }
}
