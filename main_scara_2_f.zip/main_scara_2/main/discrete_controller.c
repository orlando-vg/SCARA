#include "discrete_controller.h"

static float clampf_local(float value, float minimum, float maximum)
{
    if (value < minimum) return minimum;
    if (value > maximum) return maximum;
    return value;
}

static void calculate_coefficients(discrete_controller_t *controller)
{
    const float ratio_d = controller->tau_d / controller->sample_time;
    float ratio_i = 0.0f;

    /* Con tau_i desactivado ratio_i queda en 0 y las ecuaciones se reducen al PD. */
    if (controller->tau_i > CONTROLLER_TAU_I_MIN_S) {
        ratio_i = controller->sample_time / (2.0f * controller->tau_i);
    }

    controller->q0 = controller->kp * (1.0f + ratio_i + ratio_d);
    controller->q1 = controller->kp * (ratio_i - 1.0f - 2.0f * ratio_d);
    controller->q2 = controller->kp * ratio_d;
}

void discrete_controller_init(
    discrete_controller_t *controller,
    float kp,
    float tau_d,
    float tau_i,
    float sample_time,
    float output_min,
    float output_max)
{
    controller->kp = kp;
    controller->tau_d = tau_d;
    controller->tau_i = tau_i;
    controller->sample_time = sample_time;
    controller->output_min = output_min;
    controller->output_max = output_max;
    calculate_coefficients(controller);
    discrete_controller_reset(controller);
}

void discrete_controller_set_gains(
    discrete_controller_t *controller,
    float kp,
    float tau_d,
    float tau_i)
{
    controller->kp = kp;
    controller->tau_d = tau_d;
    controller->tau_i = tau_i;
    calculate_coefficients(controller);
    discrete_controller_reset(controller);
}

void discrete_controller_reset(discrete_controller_t *controller)
{
    controller->error_n_1 = 0.0f;
    controller->error_n_2 = 0.0f;
    controller->control_n_1 = 0.0f;
    controller->last_unsaturated = 0.0f;
    controller->last_output = 0.0f;
    controller->saturated = 0;
}

void discrete_controller_force_output(
    discrete_controller_t *controller,
    float output)
{
    output = clampf_local(output, controller->output_min, controller->output_max);
    controller->control_n_1 = output;
    controller->last_output = output;
}

float discrete_controller_update(
    discrete_controller_t *controller,
    float reference,
    float measurement)
{
    const float error_n = reference - measurement;
    const float delta_u =
        controller->q0 * error_n +
        controller->q1 * controller->error_n_1 +
        controller->q2 * controller->error_n_2;

    const float unsaturated = controller->control_n_1 + delta_u;
    const float saturated = clampf_local(
        unsaturated, controller->output_min, controller->output_max);

    /*
     * Anti-windup para forma incremental:
     * el estado u[n-1] recibe la salida saturada, nunca la salida sin limite.
     * Por ello no crece mas alla de +-12 V durante la saturacion.
     */
    controller->last_unsaturated = unsaturated;
    controller->last_output = saturated;
    controller->saturated = unsaturated != saturated;
    controller->control_n_1 = saturated;
    controller->error_n_2 = controller->error_n_1;
    controller->error_n_1 = error_n;
    return saturated;
}
