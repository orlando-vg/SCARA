#ifndef CONTROL_REVOLUTA1_H
#define CONTROL_REVOLUTA1_H

void revoluta1_init(void);

void revoluta1_set_reference(float ref_deg);

float revoluta1_get_position(void);

float revoluta1_get_voltage(void);

#endif