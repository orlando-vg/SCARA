#include <stdio.h>
#include <stdbool.h>
#include <math.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "driver/pulse_cnt.h"
#include "esp_timer.h"

#include "control_revoluta1.h"


/* ============ CONFIGURACION ============ */

// Controlador C(z) = (q0 + q1 z^-1 + q2 z^-2) / (1 - z^-1)
#define Q0             8.885f
#define Q1           -16.474f
#define Q2             7.645f
#define TS_US          5000
#define TS_S           (TS_US * 1e-6f)

#define V_MAX          12.0f


// Pines TB6612
#define PIN_STBY       GPIO_NUM_2
#define PIN_AIN1       GPIO_NUM_0
#define PIN_AIN2       GPIO_NUM_4
#define PIN_PWMA       GPIO_NUM_16


// Encoder
#define PIN_ENC_A      GPIO_NUM_39
#define PIN_ENC_B      GPIO_NUM_34
#define CPR_MOTOR      64.0f
#define GEAR_RATIO     50.0f
#define SENTIDO_ENC    -1


/* ============ VARIABLES ============ */

static pcnt_unit_handle_t pcnt;

static float I = 0.0f;
static float e_ant = 0.0f;

static volatile float ref_deg = 0.0f;
static volatile float y_log = 0.0f;
static volatile float u_log = 0.0f;


/* ============ ENCODER ============ */

static void encoder_init(void)
{
    pcnt_unit_config_t cfg = {
        .high_limit = 32767,
        .low_limit = -32768,
        .flags.accum_count = true
    };

    pcnt_new_unit(&cfg, &pcnt);

    pcnt_glitch_filter_config_t f = {
        .max_glitch_ns = 1000
    };

    pcnt_unit_set_glitch_filter(pcnt, &f);

    pcnt_channel_handle_t a, b;

    pcnt_chan_config_t ca = {
        .edge_gpio_num = PIN_ENC_A,
        .level_gpio_num = PIN_ENC_B
    };

    pcnt_chan_config_t cb = {
        .edge_gpio_num = PIN_ENC_B,
        .level_gpio_num = PIN_ENC_A
    };

    pcnt_new_channel(pcnt, &ca, &a);
    pcnt_new_channel(pcnt, &cb, &b);

    // Cuadratura x4
    pcnt_channel_set_edge_action(
        a,
        PCNT_CHANNEL_EDGE_ACTION_DECREASE,
        PCNT_CHANNEL_EDGE_ACTION_INCREASE
    );

    pcnt_channel_set_level_action(
        a,
        PCNT_CHANNEL_LEVEL_ACTION_KEEP,
        PCNT_CHANNEL_LEVEL_ACTION_INVERSE
    );

    pcnt_channel_set_edge_action(
        b,
        PCNT_CHANNEL_EDGE_ACTION_INCREASE,
        PCNT_CHANNEL_EDGE_ACTION_DECREASE
    );

    pcnt_channel_set_level_action(
        b,
        PCNT_CHANNEL_LEVEL_ACTION_KEEP,
        PCNT_CHANNEL_LEVEL_ACTION_INVERSE
    );

    pcnt_unit_add_watch_point(pcnt, 32767);
    pcnt_unit_add_watch_point(pcnt, -32768);

    pcnt_unit_enable(pcnt);
    pcnt_unit_clear_count(pcnt);
    pcnt_unit_start(pcnt);
}


/* ============ MOTOR ============ */

static void motor_init(void)
{
    gpio_config_t io = {
        .pin_bit_mask =
            (1ULL << PIN_STBY) |
            (1ULL << PIN_AIN1) |
            (1ULL << PIN_AIN2),

        .mode = GPIO_MODE_OUTPUT
    };

    gpio_config(&io);

    ledc_timer_config_t t = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .timer_num = LEDC_TIMER_0,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .freq_hz = 20000,
        .clk_cfg = LEDC_AUTO_CLK
    };

    ledc_timer_config(&t);

    ledc_channel_config_t c = {
        .gpio_num = PIN_PWMA,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_0,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0
    };

    ledc_channel_config(&c);

    gpio_set_level(PIN_STBY, 1);
}


// Voltaje (-12..12 V) -> direccion + PWM
static void motor_voltaje(float v)
{
    gpio_set_level(PIN_AIN1, v > 0);
    gpio_set_level(PIN_AIN2, v < 0);

    ledc_set_duty(
        LEDC_LOW_SPEED_MODE,
        LEDC_CHANNEL_0,
        (uint32_t)(fabsf(v) / V_MAX * 1023.0f)
    );

    ledc_update_duty(
        LEDC_LOW_SPEED_MODE,
        LEDC_CHANNEL_0
    );
}


/* ============ CONTROL ============ */

static void control(void *arg)
{
    // Ganancias equivalentes a C(z)
    const float Kp = -Q1 - 2.0f * Q2;
    const float Ki = (Q0 + Q1 + Q2) / TS_S;
    const float Kd = Q2 * TS_S;


    // Todo en rad del eje del motor
    int cuentas;
    pcnt_unit_get_count(pcnt, &cuentas);

    float y =
        SENTIDO_ENC *
        cuentas *
        2.0f *
        (float)M_PI /
        CPR_MOTOR;


    float r =
        ref_deg *
        (float)M_PI /
        180.0f *
        GEAR_RATIO;


    float e = r - y;


    // PID
    float u =
        Kp * e +
        I +
        Kd * (e - e_ant) / TS_S;


    e_ant = e;


    // Saturacion + antiwindup
    if (u > V_MAX)
    {
        u = V_MAX;
    }
    else if (u < -V_MAX)
    {
        u = -V_MAX;
    }
    else
    {
        I += Ki * TS_S * e;
    }


    motor_voltaje(u);


    y_log =
        y *
        180.0f /
        (float)M_PI /
        GEAR_RATIO;

    u_log = u;
}


/* ============ FUNCIONES PUBLICAS ============ */

void revoluta1_init(void)
{
    encoder_init();
    motor_init();

    esp_timer_create_args_t args = {
        .callback = control,
        .name = "pid_revoluta1"
    };

    esp_timer_handle_t tmr;

    esp_timer_create(&args, &tmr);
    esp_timer_start_periodic(tmr, TS_US);
}


void revoluta1_set_reference(float nueva_ref_deg)
{
    ref_deg = nueva_ref_deg;
}


float revoluta1_get_position(void)
{
    return y_log;
}


float revoluta1_get_voltage(void)
{
    return u_log;
}

Y deja tu control_revoluta1.h así:
#ifndef CONTROL_REVOLUTA1_H
#define CONTROL_REVOLUTA1_H

void revoluta1_init(void);

void revoluta1_set_reference(float ref_deg);

float revoluta1_get_position(void);

float revoluta1_get_voltage(void);

#endif