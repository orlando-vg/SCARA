#include "motor_driver.h"

#include <math.h>
#include "board_config.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "esp_err.h"

#define PWM_SPEED_MODE  LEDC_LOW_SPEED_MODE
#define PWM_TIMER       LEDC_TIMER_0
#define PWM_DUTY_MAX    ((1U << PWM_DUTY_BITS) - 1U)

_Static_assert((unsigned long long)PWM_FREQ_HZ * (1ULL << PWM_DUTY_BITS) <= 80000000ULL,
               "PWM_FREQ_HZ x 2^PWM_DUTY_BITS excede el reloj de 80 MHz de LEDC");

static motor_driver_t s_motors[JOINT_COUNT] = {
    [JOINT_P] = {
        .joint = JOINT_P,
        .stby_gpio = STBY_P_GPIO,
        .dir1_gpio = DIR1_P_GPIO,
        .dir2_gpio = DIR2_P_GPIO,
        .pwm_gpio = PWM_P_GPIO,
        .ledc_channel = LEDC_CHANNEL_0,
        .positive_voltage_toward_limit = true,
        .invert_polarity = MOTOR_P_INVERT_POLARITY,
    },
    [JOINT_R1] = {
        .joint = JOINT_R1,
        .stby_gpio = STBY_R_GPIO,
        .dir1_gpio = DIR1_R1_GPIO,
        .dir2_gpio = DIR2_R1_GPIO,
        .pwm_gpio = PWM_R1_GPIO,
        .ledc_channel = LEDC_CHANNEL_1,
        .positive_voltage_toward_limit = false,
        .invert_polarity = MOTOR_R1_INVERT_POLARITY,
    },
    [JOINT_R2] = {
        .joint = JOINT_R2,
        .stby_gpio = STBY_R_GPIO,
        .dir1_gpio = DIR1_R2_GPIO,
        .dir2_gpio = DIR2_R2_GPIO,
        .pwm_gpio = PWM_R2_GPIO,
        .ledc_channel = LEDC_CHANNEL_2,
        .positive_voltage_toward_limit = false,
        .invert_polarity = MOTOR_R2_INVERT_POLARITY,
    },
};

static float clampf_local(float value, float minimum, float maximum)
{
    if (value < minimum) return minimum;
    if (value > maximum) return maximum;
    return value;
}

static void set_duty(const motor_driver_t *motor, uint32_t counts)
{
    ESP_ERROR_CHECK(ledc_set_duty(PWM_SPEED_MODE, motor->ledc_channel, counts));
    ESP_ERROR_CHECK(ledc_update_duty(PWM_SPEED_MODE, motor->ledc_channel));
}

/* sign: +1 -> IN1=1, IN2=0 | -1 -> IN1=0, IN2=1 | 0 -> IN1=0, IN2=0 (stop). */
static void write_direction(const motor_driver_t *motor, int sign)
{
    int level1 = 0;
    int level2 = 0;
    if (sign != 0) {
        const bool forward = (sign > 0) != motor->invert_polarity;
        level1 = forward ? 1 : 0;
        level2 = forward ? 0 : 1;
    }
    gpio_set_level(motor->dir1_gpio, level1);
    gpio_set_level(motor->dir2_gpio, level2);
}

/*
 * Cada TB6612 solo sale de standby si alguno de sus motores tiene duty > 0.
 * STBY_R es compartido por R1 y R2.
 */
static void update_standby(void)
{
    if (!ACTUATION_ENABLED) return;
    for (int i = 0; i < JOINT_COUNT; ++i) {
        bool active = false;
        for (int j = 0; j < JOINT_COUNT; ++j) {
            if (s_motors[j].stby_gpio == s_motors[i].stby_gpio &&
                s_motors[j].duty_counts > 0) {
                active = true;
            }
        }
        gpio_set_level(s_motors[i].stby_gpio, active ? 1 : 0);
    }
}

void motor_driver_init_all(void)
{
    /* 1. Todo en bajo: STBY, DIR y PWM. Los drivers quedan en standby. */
    const gpio_config_t output_config = {
        .pin_bit_mask =
            (1ULL << STBY_P_GPIO) |
            (1ULL << DIR1_P_GPIO) |
            (1ULL << DIR2_P_GPIO) |
            (1ULL << PWM_P_GPIO) |
            (1ULL << STBY_R_GPIO) |
            (1ULL << DIR1_R1_GPIO) |
            (1ULL << DIR2_R1_GPIO) |
            (1ULL << PWM_R1_GPIO) |
            (1ULL << DIR1_R2_GPIO) |
            (1ULL << DIR2_R2_GPIO) |
            (1ULL << PWM_R2_GPIO),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&output_config));
    gpio_set_level(STBY_P_GPIO, 0);
    gpio_set_level(STBY_R_GPIO, 0);
    for (int i = 0; i < JOINT_COUNT; ++i) {
        gpio_set_level(s_motors[i].dir1_gpio, 0);
        gpio_set_level(s_motors[i].dir2_gpio, 0);
        gpio_set_level(s_motors[i].pwm_gpio, 0);
    }

    /* 2. LEDC: un timer compartido y un canal por motor, todos con duty 0. */
    const ledc_timer_config_t timer_config = {
        .speed_mode = PWM_SPEED_MODE,
        .duty_resolution = (ledc_timer_bit_t)PWM_DUTY_BITS,
        .timer_num = PWM_TIMER,
        .freq_hz = PWM_FREQ_HZ,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_config));

    for (int i = 0; i < JOINT_COUNT; ++i) {
        const ledc_channel_config_t channel_config = {
            .gpio_num = s_motors[i].pwm_gpio,
            .speed_mode = PWM_SPEED_MODE,
            .channel = s_motors[i].ledc_channel,
            .intr_type = LEDC_INTR_DISABLE,
            .timer_sel = PWM_TIMER,
            .duty = 0,
            .hpoint = 0,
        };
        ESP_ERROR_CHECK(ledc_channel_config(&channel_config));

        s_motors[i].requested_voltage = 0.0f;
        s_motors[i].duty_fraction = 0.0f;
        s_motors[i].duty_counts = 0;
        s_motors[i].drive_sign = 0;
        s_motors[i].direction = MOTOR_STOPPED;
    }
}

void motor_driver_apply_voltage(joint_id_t joint, float requested_voltage)
{
    if (joint < 0 || joint >= JOINT_COUNT) return;
    motor_driver_t *motor = &s_motors[joint];

    /* Un NaN nunca debe llegar al PWM. */
    if (isnan(requested_voltage)) requested_voltage = 0.0f;

    const float voltage = clampf_local(requested_voltage, ACTUATOR_MIN_V, ACTUATOR_MAX_V);
    const float fraction = clampf_local(fabsf(voltage) / MOTOR_SUPPLY_V, 0.0f, 1.0f);
    const uint32_t counts = (uint32_t)lroundf(fraction * (float)PWM_DUTY_MAX);
    const int sign = counts == 0 ? 0 : (voltage > 0.0f ? 1 : -1);

    if (ACTUATION_ENABLED && (counts != motor->duty_counts || sign != motor->drive_sign)) {
        if (sign != motor->drive_sign) {
            /* Cambio de sentido o parada: duty a 0 antes de tocar DIR1/DIR2. */
            set_duty(motor, 0);
            write_direction(motor, sign);
        }
        set_duty(motor, counts);
    }

    motor->requested_voltage = voltage;
    motor->duty_counts = counts;
    motor->duty_fraction = (float)counts / (float)PWM_DUTY_MAX;
    motor->drive_sign = sign;
    if (sign == 0) {
        motor->direction = MOTOR_STOPPED;
    } else {
        const bool toward = (voltage > 0.0f) == motor->positive_voltage_toward_limit;
        motor->direction = toward ? MOTOR_TOWARD_LIMIT : MOTOR_AWAY_FROM_LIMIT;
    }

    update_standby();
}

void motor_driver_stop_all(void)
{
    for (int i = 0; i < JOINT_COUNT; ++i) {
        motor_driver_apply_voltage((joint_id_t)i, 0.0f);
    }
}

bool motor_driver_voltage_is_toward_limit(joint_id_t joint, float voltage)
{
    if (joint < 0 || joint >= JOINT_COUNT) return false;
    if (isnan(voltage) || voltage == 0.0f) return false;
    return (voltage > 0.0f) == s_motors[joint].positive_voltage_toward_limit;
}

const motor_driver_t *motor_driver_get(joint_id_t joint)
{
    return (joint >= 0 && joint < JOINT_COUNT) ? &s_motors[joint] : 0;
}

const char *motor_direction_name(motor_direction_t direction)
{
    switch (direction) {
        case MOTOR_TOWARD_LIMIT: return "HACIA_FIN";
        case MOTOR_AWAY_FROM_LIMIT: return "ALEJANDOSE_FIN";
        default: return "DETENIDO";
    }
}
