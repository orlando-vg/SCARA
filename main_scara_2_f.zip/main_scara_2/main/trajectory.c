#include "trajectory.h"

static float clampf_local(float value, float minimum, float maximum)
{
    if (value < minimum) return minimum;
    if (value > maximum) return maximum;
    return value;
}

void trajectory_init(trajectory_t *trajectory, float initial, float max_rate)
{
    trajectory->current = initial;
    trajectory->target = initial;
    trajectory->max_rate = max_rate;
}

void trajectory_set_target(trajectory_t *trajectory, float target)
{
    trajectory->target = target;
}

float trajectory_update(trajectory_t *trajectory, float sample_time_s)
{
    float error = trajectory->target - trajectory->current;
    float maximum_step = trajectory->max_rate * sample_time_s;
    trajectory->current += clampf_local(error, -maximum_step, maximum_step);
    return trajectory->current;
}
