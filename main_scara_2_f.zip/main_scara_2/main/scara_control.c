#include "scara_control.h"

#include <stdbool.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "board_config.h"
#include "discrete_controller.h"
#include "encoder.h"
#include "homing.h"
#include "joint_model.h"
#include "limit_switch.h"
#include "motor_driver.h"
#include "robot_types.h"
#include "trajectory.h"


/* ============ ESTADO DE CADA ARTICULACION ============ */

typedef struct
{
    trajectory_t trajectory;
    discrete_controller_t controller;
    float position;
    float voltage;
} joint_runtime_t;


/* ============ VARIABLES ============ */

static system_state_t system_state = SYSTEM_WAIT_HOME;

static homing_manager_t homing;

static joint_runtime_t joint[JOINT_COUNT];

static bool referenced = false;


/* ============ VELOCIDAD MAXIMA DE REFERENCIA ============ */

static float max_rate(joint_id_t id)
{
    if (id == JOINT_P)
        return P_MAX_RATE_M_S;

    if (id == JOINT_R1)
        return R1_MAX_RATE_RAD_S;

    return R2_MAX_RATE_RAD_S;
}


/* ============ INICIALIZAR CONTROLADORES ============ */

static void runtime_init(void)
{
    for (int i = 0; i < JOINT_COUNT; i++)
    {
        trajectory_init(
            &joint[i].trajectory,
            0.0f,
            max_rate((joint_id_t)i)
        );
    }

    discrete_controller_init(
        &joint[JOINT_P].controller,
        P_KP_INITIAL,
        P_TD_INITIAL,
        P_TI_INITIAL,
        CONTROL_TS_S,
        ACTUATOR_MIN_V,
        ACTUATOR_MAX_V
    );

    discrete_controller_init(
        &joint[JOINT_R1].controller,
        R1_KP_INITIAL,
        R1_TD_INITIAL,
        R1_TI_INITIAL,
        CONTROL_TS_S,
        ACTUATOR_MIN_V,
        ACTUATOR_MAX_V
    );

    discrete_controller_init(
        &joint[JOINT_R2].controller,
        R2_KP_INITIAL,
        R2_TD_INITIAL,
        R2_TI_INITIAL,
        CONTROL_TS_S,
        ACTUATOR_MIN_V,
        ACTUATOR_MAX_V
    );
}


/* ============ DETENER CONTROL ============ */

static void stop_control(void)
{
    motor_driver_stop_all();

    for (int i = 0; i < JOINT_COUNT; i++)
    {
        discrete_controller_reset(
            &joint[i].controller
        );

        joint[i].voltage = 0.0f;
    }
}


/* ============ LEER POSICIONES ACTUALES ============ */

static void update_positions(void)
{
    for (int i = 0; i < JOINT_COUNT; i++)
    {
        joint[i].position =
            joint_position_from_pulses(
                (joint_id_t)i,
                encoder_get_pulses((joint_id_t)i)
            );
    }
}


/* ============ REFERENCIAS = POSICION ACTUAL ============ */

static void set_targets_to_current_position(void)
{
    update_positions();

    for (int i = 0; i < JOINT_COUNT; i++)
    {
        trajectory_init(
            &joint[i].trajectory,
            joint[i].position,
            max_rate((joint_id_t)i)
        );
    }
}


/* ============ VERIFICAR RECORRIDO ============ */

static bool position_within_travel(
    joint_id_t id,
    float position
)
{
    float margin;

    if (id == JOINT_P)
        margin = SOFT_LIMIT_MARGIN_P_M;
    else
        margin = SOFT_LIMIT_MARGIN_R_RAD;

    return
        position >= joint_min_position(id) - margin &&
        position <= joint_max_position(id) + margin;
}


/* ============ PASO DE CONTROL ============ */

static void control_step(void)
{
    /*
     * Primero verificamos que ninguna articulacion
     * haya salido de sus limites.
     */

    for (int i = 0; i < JOINT_COUNT; i++)
    {
        if (!position_within_travel(
                (joint_id_t)i,
                joint[i].position))
        {
            stop_control();

            referenced = false;
            system_state = SYSTEM_FAULT;

            printf(
                "FALLO: articulacion %d fuera de recorrido\n",
                i
            );

            return;
        }
    }


    /*
     * Control de las tres articulaciones.
     */

    for (int i = 0; i < JOINT_COUNT; i++)
    {
        joint_id_t id = (joint_id_t)i;


        // Referencia suavizada
        float reference =
            trajectory_update(
                &joint[i].trajectory,
                CONTROL_TS_S
            );


        // Controlador digital
        float voltage =
            discrete_controller_update(
                &joint[i].controller,
                reference,
                joint[i].position
            );


        // Error actual
        float error =
            reference -
            joint[i].position;


        /* ============ COMPENSACION ZONA MUERTA ============ */

        float deadzone_v = 1.2f;
        float error_threshold;

        if (id == JOINT_P)
            error_threshold = 0.001f;
        else
            error_threshold = 0.005f;


        if (error > error_threshold)
        {
            voltage += deadzone_v;
        }
        else if (error < -error_threshold)
        {
            voltage -= deadzone_v;
        }


        /* ============ FINAL DE CARRERA ============ */

        if (
            limit_switch_is_pressed(id) &&
            motor_driver_voltage_is_toward_limit(
                id,
                voltage
            )
        )
        {
            voltage = 0.0f;

            discrete_controller_force_output(
                &joint[i].controller,
                0.0f
            );
        }


        joint[i].voltage = voltage;

        motor_driver_apply_voltage(
            id,
            voltage
        );
    }
}


/* ============ TAREA DE CONTROL ============ */

static void control_task(void *argument)
{
    (void)argument;

    TickType_t last_wake =
        xTaskGetTickCount();


    while (true)
    {
        /* Actualizar finales de carrera */

        limit_switches_update(
            CONTROL_TASK_MS
        );


        /* Leer los tres encoders */

        update_positions();


        /* HOMING */

        if (system_state == SYSTEM_HOMING)
        {
            homing_update(
                &homing,
                CONTROL_TASK_MS
            );


            if (homing.complete)
            {
                set_targets_to_current_position();

                referenced = true;

                system_state = SYSTEM_READY;

                printf(
                    "Homing completo. SCARA listo.\n"
                );
            }


            else if (homing.fault)
            {
                referenced = false;

                system_state = SYSTEM_FAULT;

                motor_driver_stop_all();

                printf(
                    "Fallo durante homing.\n"
                );
            }
        }


        /* CONTROL NORMAL */

        else if (system_state == SYSTEM_CONTROL)
        {
            control_step();
        }


        /* Si no estamos controlando, motores detenidos */

        else
        {
            motor_driver_stop_all();
        }


        vTaskDelayUntil(
            &last_wake,
            pdMS_TO_TICKS(CONTROL_TASK_MS)
        );
    }
}


/* =========================================================
 *                  FUNCIONES PUBLICAS
 * ========================================================= */


/* ============ INICIALIZACION ============ */

void scara_control_init(void)
{
    /*
     * Inicializacion de hardware
     */

    motor_driver_init_all();

    limit_switches_init();

    encoders_init();


    /*
     * Inicializacion del control
     */

    runtime_init();

    homing_init(&homing);

    set_targets_to_current_position();


    /*
     * Crear tarea que controla continuamente
     * las tres articulaciones.
     */

    xTaskCreate(
        control_task,
        "scara_control",
        8192,
        NULL,
        6,
        NULL
    );


    printf(
        "Control SCARA inicializado.\n"
    );


#if AUTO_HOME_ON_BOOT

    scara_control_start_homing();

#endif
}


/* ============ INICIAR HOMING ============ */

void scara_control_start_homing(void)
{
    stop_control();

    referenced = false;

    homing_start(&homing);

    system_state = SYSTEM_HOMING;

    printf(
        "Iniciando homing del SCARA...\n"
    );
}

void scara_control_stop(void)
{
    if (system_state != SYSTEM_CONTROL &&
        system_state != SYSTEM_READY) {
        return;
    }

    update_positions();

    stop_control();

    set_targets_to_current_position();

    if (referenced) {
        system_state = SYSTEM_READY;
    }
}


/* ============ ENVIAR NUEVAS REFERENCIAS ============ */

bool scara_control_set_targets(
    float d1,
    float theta2,
    float theta3
)
{
    /*
     * Antes del homing no conocemos
     * realmente la posicion del robot.
     */

    if (!referenced)
    {
        return false;
    }


    /*
     * Verificar que las referencias
     * esten dentro de los limites.
     */

    if (!joint_target_is_valid(
            JOINT_P,
            d1))
    {
        return false;
    }


    if (!joint_target_is_valid(
            JOINT_R1,
            theta2))
    {
        return false;
    }


    if (!joint_target_is_valid(
            JOINT_R2,
            theta3))
    {
        return false;
    }


    /*
     * Enviar referencias a las trayectorias.
     */

    trajectory_set_target(
        &joint[JOINT_P].trajectory,
        d1
    );

    trajectory_set_target(
        &joint[JOINT_R1].trajectory,
        theta2
    );

    trajectory_set_target(
        &joint[JOINT_R2].trajectory,
        theta3
    );


    /*
     * La primera referencia despues del homing
     * inicia automaticamente el control.
     */

    if (system_state == SYSTEM_READY)
    {
        for (int i = 0; i < JOINT_COUNT; i++)
        {
            discrete_controller_reset(
                &joint[i].controller
            );

            joint[i].trajectory.current =
                joint[i].position;
        }

        system_state = SYSTEM_CONTROL;
    }


    return true;
}


/* ============ SABER SI EL ROBOT ESTA REFERENCIADO ============ */

bool scara_control_is_ready(void)
{
    return
        referenced &&
        (
            system_state == SYSTEM_READY ||
            system_state == SYSTEM_CONTROL
        );
}


/* ============ TELEMETRIA ============ */

void scara_control_get_feedback(scara_feedback_t *out)
{
    if (out == NULL)
    {
        return;
    }

    for (int i = 0; i < JOINT_COUNT; i++)
    {
        out->target[i]    = joint[i].trajectory.target;
        out->reference[i] = joint[i].trajectory.current;
        out->measured[i]  = joint[i].position;
    }

    out->state = system_state;
}


const char *scara_control_state_name(system_state_t state)
{
    switch (state)
    {
        case SYSTEM_WAIT_HOME: return "WAIT_HOME";
        case SYSTEM_HOMING:    return "HOMING";
        case SYSTEM_READY:     return "READY";
        case SYSTEM_CONTROL:   return "CONTROL";
        case SYSTEM_FAULT:     return "FAULT";
        default:               return "UNKNOWN";
    }
}