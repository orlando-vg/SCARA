#include "IK.h"
#include <math.h>

bool inverse_kinematics(
    double x,
    double y,
    double z,
    IK_Solution *solution_1,
    IK_Solution *solution_2
)
{
    double x_offset = 0.0855;

    double xr = x - x_offset;
    double yr = y;

    double L1 = 0.101;
    double L2 = 0.08291;

    double offset = 0.1135;
    double d1 = z + offset;

    double c3 =
        (xr*xr + yr*yr - L1*L1 - L2*L2)
        /
        (2.0 * L1 * L2);

    if (c3 < -1.0 || c3 > 1.0)
    {
        return false;
    }

    double s3_1 = sqrt(1.0 - c3*c3);
    double s3_2 = -s3_1;

    double theta3_1 = atan2(s3_1, c3);
    double theta3_2 = atan2(s3_2, c3);

    double theta2_1 =
        atan2(yr, xr)
        -
        atan2(
            L2 * sin(theta3_1),
            L1 + L2 * cos(theta3_1)
        );

    double theta2_2 =
        atan2(yr, xr)
        -
        atan2(
            L2 * sin(theta3_2),
            L1 + L2 * cos(theta3_2)
        );

    solution_1->d1 = d1;
    solution_1->theta2 = theta2_1;
    solution_1->theta3 = -theta3_1;

    solution_2->d1 = d1;
    solution_2->theta2 = theta2_2;
    solution_2->theta3 = -theta3_2;

    return true;
    
    
}