#ifndef HOMING_H
#define HOMING_H

#include <stdbool.h>
#include <stdint.h>
#include "robot_types.h"

typedef enum {
    HOMING_IDLE = 0,
    HOMING_SEEK_SWITCH,
    HOMING_BACKOFF,
    HOMING_SECOND_APPROACH,
    HOMING_MOVE_TO_DH_HOME,
    HOMING_COMPLETE,
    HOMING_FAULT
} homing_joint_state_t;

typedef struct {
    joint_id_t active_joint;
    homing_joint_state_t state;
    uint32_t state_elapsed_ms;
    int32_t state_start_pulses;
    int drive_sign;
    const char *fault_reason;
    bool running;
    bool complete;
    bool fault;
} homing_manager_t;

void homing_init(homing_manager_t *manager);
void homing_start(homing_manager_t *manager);
void homing_cancel(homing_manager_t *manager);
void homing_update(homing_manager_t *manager, uint32_t elapsed_ms);
const char *homing_state_name(homing_joint_state_t state);

#endif
