#ifndef ENCODER_H
#define ENCODER_H

#include <stdint.h>
#include "robot_types.h"

void encoders_init(void);
int32_t encoder_get_pulses(joint_id_t joint);
int32_t encoder_get_raw_pulses(joint_id_t joint);
void encoder_set_zero(joint_id_t joint);
void encoders_set_zero_all(void);

#endif
