#ifndef SCARA_CONTROL_H
#define SCARA_CONTROL_H

#include <stdbool.h>

#include "robot_types.h"

void scara_control_init(void);

bool scara_control_set_targets(
    float d1,
    float theta2,
    float theta3
);

void scara_control_start_homing(void);

void scara_control_stop(void);

bool scara_control_is_ready(void);

/*
 * Telemetria del controlador.
 *
 * target    : objetivo final recibido (d1, theta2, theta3)
 * reference : referencia suavizada que el controlador esta siguiendo ahora
 * measured  : posicion medida por los encoders
 * Unidades: d1 en metros, theta2 y theta3 en radianes.
 */
typedef struct
{
    float target[JOINT_COUNT];
    float reference[JOINT_COUNT];
    float measured[JOINT_COUNT];
    system_state_t state;
} scara_feedback_t;

void scara_control_get_feedback(scara_feedback_t *out);

const char *scara_control_state_name(system_state_t state);

#endif