#ifndef TRAJECTORY_H
#define TRAJECTORY_H

typedef struct {
    float current;
    float target;
    float max_rate;
} trajectory_t;

void trajectory_init(trajectory_t *trajectory, float initial, float max_rate);
void trajectory_set_target(trajectory_t *trajectory, float target);
float trajectory_update(trajectory_t *trajectory, float sample_time_s);

#endif
