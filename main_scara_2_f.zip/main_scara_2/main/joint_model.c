#include "joint_model.h"
#include "board_config.h"

#define PI_F 3.14159265358979323846f
#define REV_COUNTS_PER_REV 14400.0f

float degrees_to_radians(float degrees)
{
    return degrees * PI_F / 180.0f;
}

float radians_to_degrees(float radians)
{
    return radians * 180.0f / PI_F;
}

float joint_position_from_pulses(joint_id_t joint, int32_t pulses)
{
    switch (joint) {
        case JOINT_P:
            return (float)pulses * (0.120f / 48000.0f);
        case JOINT_R1:
            return ((float)pulses - (float)R1_HOME_PULSES) *
                   (2.0f * PI_F / REV_COUNTS_PER_REV);
        case JOINT_R2:
            return ((float)pulses - (float)R2_HOME_PULSES) *
                   (2.0f * PI_F / REV_COUNTS_PER_REV);
        default:
            return 0.0f;
    }
}

float joint_home_position(joint_id_t joint)
{
    (void)joint;
    return 0.0f;
}

float joint_min_position(joint_id_t joint)
{
    const float values[JOINT_COUNT] = {P_MIN_M, R1_MIN_RAD, R2_MIN_RAD};
    return values[joint];
}

float joint_max_position(joint_id_t joint)
{
    const float values[JOINT_COUNT] = {P_MAX_M, R1_MAX_RAD, R2_MAX_RAD};
    return values[joint];
}

int32_t joint_home_pulses(joint_id_t joint)
{
    const int32_t values[JOINT_COUNT] = {
        P_HOME_PULSES, R1_HOME_PULSES, R2_HOME_PULSES};
    return values[joint];
}

int32_t joint_min_pulses(joint_id_t joint)
{
    const int32_t values[JOINT_COUNT] = {
        P_MIN_PULSES, R1_MIN_PULSES, R2_MIN_PULSES};
    return values[joint];
}

int32_t joint_max_pulses(joint_id_t joint)
{
    const int32_t values[JOINT_COUNT] = {
        P_MAX_PULSES, R1_MAX_PULSES, R2_MAX_PULSES};
    return values[joint];
}

bool joint_target_is_valid(joint_id_t joint, float target_internal)
{
    return target_internal >= joint_min_position(joint) &&
           target_internal <= joint_max_position(joint);
}
