#include "homing.h"

#include <stddef.h>
#include "board_config.h"
#include "encoder.h"
#include "joint_model.h"
#include "limit_switch.h"
#include "motor_driver.h"

static float toward_limit_voltage(joint_id_t joint, float magnitude)
{
    /*
     * Convencion de signo del modelo:
     * P:  voltaje positivo apunta hacia el final superior.
     * R1: voltaje negativo apunta hacia el final de carrera.
     * R2: voltaje negativo apunta hacia el final de carrera.
     * En las tres, voltaje positivo => el encoder cuenta hacia arriba.
     */
    return joint == JOINT_P ? magnitude : -magnitude;
}

static float away_from_limit_voltage(joint_id_t joint, float magnitude)
{
    return -toward_limit_voltage(joint, magnitude);
}

static float seek_magnitude(joint_id_t joint)
{
    const float values[JOINT_COUNT] = {
        HOMING_SEEK_V_P, HOMING_SEEK_V_R1, HOMING_SEEK_V_R2};
    return values[joint];
}

static int sign_of(float value)
{
    return (value > 0.0f) - (value < 0.0f);
}

/* Aplica voltaje y recuerda el sentido esperado del encoder. */
static void drive(homing_manager_t *manager, joint_id_t joint, float voltage)
{
    motor_driver_apply_voltage(joint, voltage);
    manager->drive_sign = sign_of(voltage);
}

static void enter_state(homing_manager_t *manager, homing_joint_state_t state)
{
    manager->state = state;
    manager->state_elapsed_ms = 0;
    manager->state_start_pulses = encoder_get_pulses(manager->active_joint);
    manager->drive_sign = 0;
}

static void fail(homing_manager_t *manager, const char *reason)
{
    motor_driver_stop_all();
    manager->running = false;
    manager->fault = true;
    manager->state = HOMING_FAULT;
    manager->fault_reason = reason;
}

static void next_joint_or_finish(homing_manager_t *manager)
{
    if (manager->active_joint == JOINT_R2) {
        manager->running = false;
        manager->complete = true;
        manager->state = HOMING_COMPLETE;
        motor_driver_stop_all();
    } else {
        manager->active_joint = (joint_id_t)(manager->active_joint + 1);
        enter_state(manager, HOMING_SEEK_SWITCH);
    }
}

void homing_init(homing_manager_t *manager)
{
    manager->active_joint = JOINT_P;
    manager->state = HOMING_IDLE;
    manager->state_elapsed_ms = 0;
    manager->state_start_pulses = 0;
    manager->drive_sign = 0;
    manager->fault_reason = NULL;
    manager->running = false;
    manager->complete = false;
    manager->fault = false;
}

void homing_start(homing_manager_t *manager)
{
    motor_driver_stop_all();
    manager->active_joint = JOINT_P;
    manager->running = true;
    manager->complete = false;
    manager->fault = false;
    manager->fault_reason = NULL;
    enter_state(manager, HOMING_SEEK_SWITCH);
}

void homing_cancel(homing_manager_t *manager)
{
    motor_driver_stop_all();
    manager->running = false;
    manager->state = HOMING_IDLE;
}

void homing_update(homing_manager_t *manager, uint32_t elapsed_ms)
{
    if (!manager->running) return;
    manager->state_elapsed_ms += elapsed_ms;
    if (manager->state_elapsed_ms > HOMING_TIMEOUT_MS) {
        fail(manager, "timeout: no se alcanzo el objetivo del estado");
        return;
    }

    const joint_id_t joint = manager->active_joint;
    const bool pressed = limit_switch_is_pressed(joint);
    const int32_t pulses = encoder_get_pulses(joint);

    /*
     * Verificacion de sentido: con voltaje positivo el encoder debe subir y
     * con negativo bajar. Si se mueve al reves => polaridad del motor o del
     * encoder invertida; se detiene antes de llegar a un tope.
     */
    if (manager->drive_sign != 0) {
        const int32_t moved = (pulses - manager->state_start_pulses) * manager->drive_sign;
        if (moved < -HOMING_WRONG_DIR_PULSES) {
            fail(manager, "sentido invertido (revise MOTOR_x_INVERT_POLARITY o el encoder)");
            return;
        }
    }

    switch (manager->state) {
        case HOMING_SEEK_SWITCH:
            drive(manager, joint, toward_limit_voltage(joint, seek_magnitude(joint)));
            if (pressed) {
                drive(manager, joint, 0.0f);
                enter_state(manager, HOMING_BACKOFF);
            }
            break;

        case HOMING_BACKOFF:
            drive(manager, joint, away_from_limit_voltage(joint, HOMING_BACKOFF_V));
            if (!pressed) {
                drive(manager, joint, 0.0f);
                enter_state(manager, HOMING_SECOND_APPROACH);
            }
            break;

        case HOMING_SECOND_APPROACH:
            drive(manager, joint, toward_limit_voltage(joint, HOMING_SECOND_V));
            if (pressed) {
                drive(manager, joint, 0.0f);
                encoder_set_zero(joint);
                if (joint_home_pulses(joint) == 0) {
                    next_joint_or_finish(manager);
                } else {
                    enter_state(manager, HOMING_MOVE_TO_DH_HOME);
                }
            }
            break;

        case HOMING_MOVE_TO_DH_HOME: {
            /*
             * Lazo abierto: el motor se detiene al LLEGAR O PASAR el home en el
             * sentido de avance. Una ventana +-N pulsos se saltaria entre dos
             * muestras de 10 ms si el motor va rapido.
             */
            const float voltage = away_from_limit_voltage(joint, HOMING_TO_HOME_V);
            const int direction = sign_of(voltage);
            drive(manager, joint, voltage);
            if ((joint_home_pulses(joint) - pulses) * direction <= HOMING_HOME_TOLERANCE_PULSES) {
                drive(manager, joint, 0.0f);
                next_joint_or_finish(manager);
            }
            break;
        }

        default:
            break;
    }
}

const char *homing_state_name(homing_joint_state_t state)
{
    switch (state) {
        case HOMING_IDLE: return "IDLE";
        case HOMING_SEEK_SWITCH: return "BUSCANDO_FIN";
        case HOMING_BACKOFF: return "RETROCESO";
        case HOMING_SECOND_APPROACH: return "SEGUNDA_APROX";
        case HOMING_MOVE_TO_DH_HOME: return "YENDO_HOME_DH";
        case HOMING_COMPLETE: return "COMPLETO";
        case HOMING_FAULT: return "FALLO";
        default: return "DESCONOCIDO";
    }
}
