// En este código definimos que le entra y que le sale a la cinemática inversa
#ifndef IK_H // Se le llama include guard
#define IK_H //Ponemos estos dos para evitar que el archivo se incluya dos veces durante la compilación
#include <stdbool.h>

typedef struct // Creamos la estructura que agrupa las tres soluciones
{
    double d1;
    double theta2;
    double theta3;
} IK_Solution;

bool inverse_kinematics( //Lo ponemos como bool para que nos devuelva true o false si la posición es alcanzable o no
    double x,
    double y,
    double z,
    IK_Solution *solution_1,
    IK_Solution *solution_2
);

#endif
